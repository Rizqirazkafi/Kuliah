Testing environment
OS-Based	: Arch Linux
OS-Distro	: ArcoLinux 
OS Kernel	: 5.9.1-arch1-1
Compiler	: gcc / g++ compiler
Terminal	: termite
IDE			: VScode - OSS
